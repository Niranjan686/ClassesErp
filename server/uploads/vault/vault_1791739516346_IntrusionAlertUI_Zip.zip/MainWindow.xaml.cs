﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Data.SqlClient;
using System.Data;

namespace IntrusionAlertUI
{
    public partial class MainWindow : Window
    {
        private string connectionString =
            @"Server=DESKTOP-C8FF4CQ\SQLEXPRESS;Database=ScanId_Gurunanak_Primary_2025_2026;User Id=sa;Password=12345678;TrustServerCertificate=True;";

        public MainWindow()
        {
            InitializeComponent();
            LoadFirstStudent();
        }

        private void LoadFirstStudent()
        {
            DataTable table = GetStudents();
            if (table.Rows.Count > 0)
            {
                DataRow row = table.Rows[0];
                NameText.Text = $"{row["FNAME"]} {row["LNAME"]}";
                StdDivText.Text = $"{row["STD"]} - {row["DIV"]}";
                RollNoText.Text = row["ROLLNO"].ToString();
                DetectedAtText.Text = DateTime.Now.ToString("dd MMM yyyy   hh:mm tt");
            }
        }

        private DataTable GetStudents()
        {
            DataTable table = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT TOP 1 FNAME, LNAME, STD, DIV, ROLLNO FROM STUDENTMASTER ORDER BY NEWID()";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(table);
            }
            return table;
        }

        private void ViewDetails_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                $"Name: {NameText.Text}\nStandard: {StdDivText.Text}\nRoll No: {RollNoText.Text}",
                "Student Details", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RestrictedArea_Click(object sender, RoutedEventArgs e)
        {
            RestrictedAreaWindow restrictedWindow = new RestrictedAreaWindow();
            restrictedWindow.Show();
        }
    }
}